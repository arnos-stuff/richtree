from .paths import (
    package_dir, base_dir, tests_dir, config_dir, safe_config_load
)