from .reader import read_file, read_dir, read
from .render import (
    build, initConfig,
    demo_symbols, demo_themes,
    tableFromRecords
)